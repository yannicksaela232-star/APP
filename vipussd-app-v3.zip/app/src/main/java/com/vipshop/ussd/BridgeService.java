package com.vipshop.ussd;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

/* Pede ao servidor os envios pendentes e executa um de cada vez. */
public class BridgeService extends Service {
    static volatile boolean ocupado = false;
    private volatile boolean ativo = true;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel canal = new NotificationChannel("vip", "VIP USSD", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(canal);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "vip")
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("VIP USSD ativo")
                .setContentText("A ligar ao servidor")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .build();
        startForeground(1, n);
        new Thread(this::ciclo).start();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onDestroy() {
        ativo = false;
        super.onDestroy();
    }

    private void ciclo() {
        while (ativo) {
            try {
                if (Config.pronto(this) && !ocupado) verificar();
            } catch (Exception e) {
                Log.e("VIP", "ciclo: " + e.getMessage());
            }
            try { Thread.sleep(8000); } catch (InterruptedException e) { return; }
        }
    }

    private void verificar() throws Exception {
        String json = Api.pedir(this, "GET", "/app/pendentes", null);
        JSONArray lista = new JSONArray(json);
        if (lista.length() == 0) return;
        JSONObject o = lista.getJSONObject(0);
        ocupado = true;
        new UssdEnvio(this, 0, o.getString("id"), String.valueOf(o.getInt("mb")), o.getString("numero"), "",
                () -> ocupado = false).executar();
    }
}
