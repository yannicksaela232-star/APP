package com.vipshop.ussd;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.Locale;

/* Recebe o SMS de pagamento e envia o texto ao bot (/api/pagamento-sms). */
public class SmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (msgs == null) return;
        StringBuilder sb = new StringBuilder();
        for (SmsMessage m : msgs) if (m != null) sb.append(m.getMessageBody());
        String texto = sb.toString();
        String n = texto.toLowerCase(Locale.ROOT);
        if (n.contains("recebeu") || n.contains("recebeste")) {
            Bot.enviar(c, "/api/pagamento-sms", texto);
        }
    }
}
