package com.vipshop.ussd;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PEDIDO_PERMISSOES = 1;
    private EditText servidor, token, chave;
    private TextView estado;

    @Override
    protected void onCreate(Bundle guardado) {
        super.onCreate(guardado);
        ScrollView sv = new ScrollView(this);
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(40, 40, 40, 40);
        sv.addView(r);

        ImageView capa = new ImageView(this);
        capa.setImageResource(R.drawable.capa);
        capa.setAdjustViewBounds(true);
        r.addView(capa);

        servidor = campo(r, "Endereço do servidor (http://IP:3000)", Config.servidor(this));
        token = campo(r, "Token do servidor", Config.token(this));
        botao(r, "Guardar", v -> guardar());
        botao(r, "Testar ligação", v -> testar());

        chave = campo(r, "Chave de acesso (VIP-...)", "");
        botao(r, "Ativar chave", v -> ativar());

        botao(r, "Iniciar", v -> pedirPermissoes());

        estado = new TextView(this);
        estado.setText(Config.pronto(this) ? "Pronto. Toca em Iniciar." : "Preenche o endereço e o token e guarda.");
        r.addView(estado);

        setContentView(sv);
    }

    private EditText campo(LinearLayout r, String dica, String valor) {
        EditText e = new EditText(this);
        e.setHint(dica);
        e.setText(valor);
        r.addView(e);
        return e;
    }

    private void botao(LinearLayout r, String texto, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(texto);
        b.setOnClickListener(l);
        r.addView(b);
    }

    private void guardar() {
        Config.p(this).edit()
                .putString("servidor", servidor.getText().toString().trim())
                .putString("token", token.getText().toString().trim())
                .apply();
        estado.setText("Guardado.");
    }

    private void mostrar(String texto) {
        runOnUiThread(() -> estado.setText(texto));
    }

    private void testar() {
        guardar();
        new Thread(() -> {
            try {
                String r = Api.pedir(this, "GET", "/app/resumo", null);
                mostrar("Ligação OK: " + (r.length() > 200 ? r.substring(0, 200) : r));
            } catch (Exception e) {
                mostrar("Falhou: " + e.getMessage());
            }
        }).start();
    }

    private void ativar() {
        guardar();
        final String k = chave.getText().toString().trim();
        new Thread(() -> {
            try {
                String r = Api.pedir(this, "POST", "/app/ativar", k);
                JSONObject o = new JSONObject(r);
                if (o.optBoolean("ok")) mostrar("Acesso ativo até: " + o.optString("validade"));
                else mostrar("Erro: " + o.optString("erro"));
            } catch (Exception e) {
                mostrar("Falhou: " + e.getMessage());
            }
        }).start();
    }

    private void pedirPermissoes() {
        guardar();
        ArrayList<String> lista = new ArrayList<>();
        lista.add(Manifest.permission.RECEIVE_SMS);
        lista.add(Manifest.permission.CALL_PHONE);
        lista.add(Manifest.permission.READ_PHONE_STATE);
        if (Build.VERSION.SDK_INT >= 33) lista.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(lista.toArray(new String[0]), PEDIDO_PERMISSOES);
    }

    @Override
    public void onRequestPermissionsResult(int codigo, String[] permissoes, int[] resultados) {
        super.onRequestPermissionsResult(codigo, permissoes, resultados);
        if (codigo != PEDIDO_PERMISSOES) return;
        Intent i = new Intent(this, BridgeService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        estado.setText("Ativo: a ligar ao servidor e a receber pedidos.\nNão feches a app.");
    }
}
